// 설치나 번들러 없이 단일 HTML 파일을 만드는 선택적 개발 도구입니다.
import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
const root = new URL('../', import.meta.url);
let html = await readFile(new URL('index.html', root), 'utf8');
const css = await readFile(new URL('assets/style.css', root), 'utf8');
html = html.replace('<link rel="stylesheet" href="assets/style.css"/>', `<style>\n${css}\n</style>`);
for (const name of ['config', 'core', 'signals', 'vision', 'app']) {
  const code = await readFile(new URL(`assets/${name}.js`, root), 'utf8');
  html = html.replace(`<script src="assets/${name}.js" defer></script>`, `<script>\n${code}\n</script>`);
}
const destination = new URL('졸지마_AI연결버전.html', root);
await writeFile(destination, html);
console.log(`생성됨: ${fileURLToPath(destination)}`);
