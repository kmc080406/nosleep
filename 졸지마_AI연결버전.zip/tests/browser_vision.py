"""Browser/Worker integration using synthetic outputs, NOT real model evaluation."""
from pathlib import Path
import json, re, os, base64
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent.parent
OUT=Path(os.environ.get('JOLJIMA_QA_DIR',str(ROOT/'test-results')));OUT.mkdir(parents=True,exist_ok=True)
FIXTURE=(ROOT/'tests/fixtures.cjs').read_text().split('module.exports=')[0]
MOCK_MODULE=FIXTURE+'''
const readMode=frame=>{const c=new OffscreenCanvas(1,1);const ctx=c.getContext('2d');ctx.drawImage(frame,0,0,1,1);return ctx.getImageData(0,0,1,1).data[0];};
export const FilesetResolver={forVisionTasks:async()=>({})};
export class FaceLandmarker{
 static async createFromOptions(){return new FaceLandmarker();}
 detectForVideo(frame){const n=readMode(frame);if(n===50||n===100||n===20)return {faceLandmarks:[],faceBlendshapes:[]};return face(n===120);}
 close(){}
}
export class PoseLandmarker{
 static async createFromOptions(){return new PoseLandmarker();}
 detectForVideo(frame){const n=readMode(frame);return {landmarks:n===50||n===20?[]:body(n===180?'lying':n===160?'head_down':'upright').poseLandmarks};}
 close(){}
}
export class HandLandmarker{
 static async createFromOptions(){return new HandLandmarker();}
 detectForVideo(frame){return {landmarks:readMode(frame)===150?handCover().handLandmarks:[]};}
 close(){}
}
'''
CAMERA='''(()=>{
Object.defineProperty(window,'isSecureContext',{configurable:true,get:()=>true});
window.QA={requests:0,stops:0,mode:200,deny:false,delay:0,frames:true};
Object.defineProperty(navigator,'mediaDevices',{configurable:true,value:{getUserMedia:async()=>{
 QA.requests++;if(QA.delay)await new Promise(r=>setTimeout(r,QA.delay));
 if(QA.deny)throw new DOMException('Camera denied','NotAllowedError');
 const c=document.createElement('canvas');c.width=640;c.height=480;const ctx=c.getContext('2d');
 const draw=()=>{if(!QA.frames)return;ctx.fillStyle=QA.mode===20?'rgb(0,0,0)':`rgb(${QA.mode},150,120)`;ctx.fillRect(0,0,640,480);};draw();
 const timer=setInterval(draw,55);const stream=c.captureStream(18);
 for(const t of stream.getTracks()){const orig=t.stop.bind(t);t.stop=()=>{if(t.readyState!=='ended'){QA.stops++;clearInterval(timer);}orig();};}
 return stream;
}}});
})();'''
checks=[];errors=[]
def check(name,condition):
 assert condition,name
 checks.append(name);print('PASS',name,flush=True)
def wait_title(page,text,timeout=18000):page.wait_for_function('(s)=>document.getElementById("monitorTitle").textContent.includes(s)',arg=text,timeout=timeout)
def no_overflow(page):return page.evaluate('document.documentElement.scrollWidth<=innerWidth')
def content():
 text=(ROOT/'졸지마_AI연결버전.html').read_text()
 module='data:text/javascript;base64,'+base64.b64encode(MOCK_MODULE.encode()).decode()
 buffer='data:application/octet-stream;base64,'+base64.b64encode(b'x'*2048).decode()
 text=re.sub(r"https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@[^']+/vision_bundle.mjs",module,text)
 text=re.sub(r"https://storage.googleapis.com/mediapipe-models/[^']+",buffer,text)
 text=text.replace('const detector = new JoljimaDetector();','const detector = new JoljimaDetector(); window.QA.detector=detector;')
 return text.replace('<head>','<head><script>'+CAMERA+'</script>',1)
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  ctx=browser.new_context(viewport={'width':1440,'height':900},reduced_motion='reduce');ctx.add_init_script(CAMERA)
  page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.on('console',lambda m: print('CONSOLE',m.type,m.text[:350],flush=True) if m.type in ['error','warning'] else None)
  page.set_content(content(),wait_until='load')
  check('시작 화면 제작자 이름',page.locator('.creator').inner_text()=='made by 김민찬')
  check('시작 전 카메라 접근 없음',page.evaluate('QA.requests')==0)
  check('시작 화면 넘침 없음',no_overflow(page));page.screenshot(path=str(OUT/'home-desktop.png'))
  page.locator('#startButton').click();wait_title(page,'눈을 뜨고')
  check('Worker 모델 로딩과 관측 입력 연동',page.locator('#monitorScreen').is_visible());check('별도 Worker 추론 경로 사용',page.evaluate('QA.detector.mode')=='worker')
  check('카메라 기본 숨김',page.locator('#cameraButton').get_attribute('aria-pressed')=='false')
  page.locator('#cameraButton').click();check('카메라 미리보기 켜짐',page.locator('#cameraButton').get_attribute('aria-pressed')=='true')
  page.locator('#cameraButton').click();check('미리보기 숨겨도 카메라 유지',page.evaluate('QA.stops')==0)
  page.locator('#settingsButton').click();page.locator('#delayInput').evaluate('(e)=>{e.value="2";e.dispatchEvent(new Event("input",{bubbles:true}));}')
  page.locator('#soundInput').uncheck();page.locator('#settingsDone').click()
  page.evaluate('QA.mode=120');wait_title(page,'눈 감김');page.wait_for_function('document.body.dataset.screen==="alarm"',timeout=8000)
  check('연속 눈 감김은 일어나 알림',page.locator('#alarmTitle').inner_text()=='일어나!')
  page.evaluate('QA.mode=200');page.locator('#awakeButton').click();wait_title(page,'눈을 뜨고')
  check('확인 후 감지 화면 복귀',page.locator('#monitorScreen').is_visible())
  page.evaluate('QA.mode=150');wait_title(page,'눈이 잘');page.wait_for_function('document.body.dataset.screen==="alarm"',timeout=8000)
  check('눈 가림은 수면 확정이 아닌 별도 확인 알림',page.locator('#alarmTitle').inner_text()=='괜찮아요?')
  check('확인 알림의 원인 표시','눈 가림' in page.locator('#alarmSubtitle').inner_text())
  page.evaluate('QA.mode=200');page.locator('#awakeButton').click();wait_title(page,'눈을 뜨고')
  page.evaluate('QA.mode=180');wait_title(page,'누운 자세');page.wait_for_function('document.body.dataset.screen==="alarm"',timeout=8000)
  check('누운 자세 확인 알림','누운 자세' in page.locator('#alarmSubtitle').inner_text())
  page.evaluate('QA.mode=200');page.locator('#awakeButton').click();wait_title(page,'눈을 뜨고')
  page.evaluate('QA.mode=50');wait_title(page,'사람을 찾고');page.wait_for_timeout(2400)
  check('사람 검출 실패에 수면 알림 없음',page.locator('#monitorScreen').is_visible())
  page.evaluate('QA.mode=20');wait_title(page,'너무 어두워');page.wait_for_timeout(2200)
  check('어두운 화면 판단 보류',page.locator('#monitorScreen').is_visible())
  page.evaluate('QA.mode=200');wait_title(page,'눈을 뜨고');page.locator('#endButton').click()
  check('종료 시 카메라 중지',page.evaluate('QA.stops')==1);check('종료 시 시작 화면 복귀',page.locator('#introScreen').is_visible())
  page.evaluate('QA.deny=true');page.locator('#startButton').click();page.wait_for_function('document.body.dataset.screen==="error"',timeout=15000)
  check('카메라 거부 안내','카메라 권한' in page.locator('#errorMessage').inner_text())
  page.locator('#errorHomeButton').click();page.evaluate('QA.deny=false;QA.delay=1500');page.locator('#startButton').click();page.wait_for_function('QA.requests>=3')
  page.locator('#cancelButton').click();page.wait_for_timeout(1800)
  check('늦게 도착한 카메라 권한 처리 후 종료',page.evaluate('QA.stops')==2)
  check('취소 후 화면 유지',page.locator('#introScreen').is_visible());check('브라우저 JS 예외 없음',not errors)
  ctx.close()
  for width,height in [(390,844),(320,568),(768,1024)]:
   c=browser.new_context(viewport={'width':width,'height':height},reduced_motion='reduce');c.add_init_script(CAMERA)
   pg=c.new_page();pg.set_content(content(),wait_until='load');check(f'{width}px 시작 화면 가로 넘침 없음',no_overflow(pg))
   if width==390:pg.screenshot(path=str(OUT/'home-mobile.png'),full_page=True)
   pg.locator('#startButton').click();wait_title(pg,'눈을 뜨고');check(f'{width}px 감지 화면 가로 넘침 없음',no_overflow(pg))
   pg.locator('#settingsButton').click();check(f'{width}px 설정 완료 버튼 접근 가능',pg.locator('#settingsDone').is_visible())
   pg.locator('#testAlarmButton').click();check(f'{width}px 알림 화면 가로 넘침 없음',no_overflow(pg))
   pg.locator('#alarmEndButton').click();c.close()
  browser.close()
finally:
 (OUT/'browser-report.json').write_text(json.dumps({'checks':checks,'errors':errors,'real_weights_tested':False,'model_output':'synthetic fixtures'},ensure_ascii=False,indent=2))
print('TOTAL',len(checks),'PASS')
