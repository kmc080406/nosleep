'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const core = fs.readFileSync(path.join(__dirname, '../assets/core.js'), 'utf8');
const api = vm.runInNewContext(core + '\nJoljimaCore;', { setTimeout, clearTimeout });
const { DrowsinessGate, classifyPredictions: classify, readSettings, normalizeSettings,
  withTimeout, PredictionSlot, disposeModel } = api;
const names = { awake: '깨어 있음', sleep: '졸음', away: '자리 비움' };
const values = (name, probability = .95) => [{ className: name, probability }];

// 분류·연속 시간: 실제 학습 모델을 쓰지 않는 결정론적 테스트.
test('5초 연속 졸음에서 한 번만 알림', () => {
  const gate = new DrowsinessGate(5);
  let alerts = 0;
  for (let t = 0; t <= 6500; t += 100) if (gate.observe('sleep', t).trigger) alerts++;
  assert.equal(alerts, 1);
});
test('기준 시간 직전에는 알림 없음', () => {
  const g = new DrowsinessGate(2);
  for (let t = 0; t <= 1900; t += 100) assert.equal(g.observe('sleep', t).trigger, false);
  assert.equal(g.observe('sleep', 2000).trigger, true);
});
for (const kind of ['awake', 'away', 'unknown']) {
  test(kind + ' 관측은 연속 졸음 시간을 초기화', () => {
    const g = new DrowsinessGate(2);
    g.observe('sleep', 0); g.observe('sleep', 800);
    assert.equal(g.observe(kind, 900).sleepMs, 0);
    assert.equal(g.observe('sleep', 1000).sleepMs, 0);
  });
}
test('오래된 프레임은 이어 붙이지 않음', () => {
  const g = new DrowsinessGate(2);
  g.observe('sleep', 0); g.observe('sleep', 900);
  assert.equal(g.observe('sleep', 2001).sleepMs, 0);
});
test('역방향 시각은 시간 누적 없음', () => {
  const g = new DrowsinessGate(2);
  g.observe('sleep', 100); g.observe('sleep', 500);
  assert.equal(g.observe('sleep', 300).sleepMs, 0);
});
test('잘못된 시각은 판단 보류', () => {
  for (const t of [NaN, Infinity, -10, '3']) {
    const g = new DrowsinessGate(2);
    assert.equal(g.observe('sleep', t).kind, 'unknown');
  }
});
test('잘못된 상태 이름은 판단 보류', () => {
  const g = new DrowsinessGate(2);
  assert.equal(g.observe('other', 0).kind, 'unknown');
});
test('초기화 후 새 졸음에 다시 알림', () => {
  const g = new DrowsinessGate(2);
  for (let t = 0; t <= 2000; t += 100) g.observe('sleep', t);
  g.reset();
  for (let t = 2100; t < 4100; t += 100) assert.equal(g.observe('sleep', t).trigger, false);
  assert.equal(g.observe('sleep', 4100).trigger, true);
});
for (const kind of ['awake', 'sleep', 'away']) {
  test(kind + ' 클래스 대응', () => assert.equal(classify(values(names[kind]), names), kind));
}
test('낮은 점수는 판단 보류', () => assert.equal(classify(values(names.sleep, .79), names), 'unknown'));
test('경계 점수 포함', () => assert.equal(classify(values(names.sleep, .8), names), 'sleep'));
test('알 수 없는 높은 점수 클래스를 다른 클래스로 대체하지 않음', () => {
  assert.equal(classify([...values('기타', .95), ...values(names.sleep, .9)], names), 'unknown');
});
test('깨진 예측값 처리', () => {
  for (const data of [null, {}, [], [null], values(names.sleep, NaN), values(names.sleep, 2)]) {
    assert.equal(classify(data, names), 'unknown');
  }
});
test('2분류 모델 허용', () => assert.equal(classify(values(names.sleep), {...names, away: ''}), 'sleep'));
test('기본 설정·경계값 검증', () => {
  assert.equal(normalizeSettings(null).seconds, 5);
  assert.equal(normalizeSettings({seconds: 31}).seconds, 5);
  assert.equal(normalizeSettings({seconds: 2.5}).seconds, 5);
  assert.equal(normalizeSettings({seconds: 30, sound: false}).sound, false);
});
test('이전 이름의 설정을 새 키로 이전', () => {
  const map = new Map([['old', '{"seconds":10,"sound":false}']]);
  const store = {getItem: k => map.get(k), setItem: (k,v) => map.set(k,v)};
  const result = readSettings(store, 'new', 'old');
  assert.equal(result.seconds, 10); assert.equal(result.sound, false);
  assert.equal(JSON.parse(map.get('new')).seconds, 10);
});
test('차단된 저장소와 손상된 JSON 처리', () => {
  assert.equal(readSettings({getItem(){throw Error();}}, 'new', 'old').seconds, 5);
  const map={new:'{broken',old:'{"seconds":7}'};
  assert.equal(readSettings({getItem:k=>map[k]}, 'new', 'old').seconds, 7);
});
test('동시 추론 진입 차단', async () => {
  const slot = new PredictionSlot();
  let resolve;
  const first = slot.run(() => new Promise(r => resolve=r), 0);
  assert.equal(slot.run(() => Promise.resolve('second'), 1), null);
  await Promise.resolve(); resolve('first');
  assert.equal(await first, 'first'); await Promise.resolve();
  assert.equal(slot.busy, false);
});
test('타임아웃이어도 실제 추론이 끝날 때까지 잠금 유지', async () => {
  const slot = new PredictionSlot(); let resolve;
  const job=slot.run(() => new Promise(r=>resolve=r), 0);
  await assert.rejects(withTimeout(job, 5, 'timeout'), /timeout/);
  assert.equal(slot.busy, true);
  resolve([]); await job; await Promise.resolve();
  assert.equal(slot.busy, false);
});
test('추론 실패 후 잠금 해제', async () => {
  const slot = new PredictionSlot();
  await assert.rejects(slot.run(() => Promise.reject(Error('failed')), 0), /failed/);
  await Promise.resolve(); assert.equal(slot.busy, false);
});
test('타임아웃 이전 완료·실패 전달', async () => {
  assert.equal(await withTimeout(Promise.resolve(42), 50, 'timeout'), 42);
  await assert.rejects(withTimeout(Promise.reject(Error('actual')), 50, 'timeout'), /actual/);
});
test('모델 내부 LayersModel을 중복 없이 정리', () => {
  let count=0; const tensor={dispose:()=>count++};
  disposeModel({model:tensor,truncatedModel:tensor});
  assert.equal(count, 1);
});
