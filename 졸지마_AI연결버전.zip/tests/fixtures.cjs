'use strict';
// Synthetic landmark coordinates for logic tests, not real training/evaluation data.
function face(closed = false, wink = false, ear = .28) {
  const p = Array.from({length:478}, () => ({x:.5,y:.35,z:0}));
  const eye = (ix, left, right, isClosed) => {
    const cy=.32, w=right-left, dy=(isClosed ? .055 : ear)*w*640/480/2;
    const [a,b,c,d,e,f]=ix;
    p[a]={x:left,y:cy,z:0}; p[d]={x:right,y:cy,z:0};
    p[b]={x:left+w*.3,y:cy-dy,z:0}; p[c]={x:left+w*.7,y:cy-dy,z:0};
    p[e]={x:left+w*.7,y:cy+dy,z:0}; p[f]={x:left+w*.3,y:cy+dy,z:0};
  };
  eye([33,160,158,133,153,144],.34,.44,closed);
  eye([362,385,387,263,373,380],.56,.66,closed && !wink);
  p[1]={x:.5,y:.40,z:-.08};
  return {faceLandmarks:[p],faceBlendshapes:[{categories:[
    {categoryName:'eyeBlinkLeft',score:closed?.95:.03},
    {categoryName:'eyeBlinkRight',score:closed&&!wink?.95:.03}
  ]}]};
}
function body(kind='upright') {
  const p=Array.from({length:33},()=>({x:.5,y:.5,z:0,visibility:.1,presence:1}));
  const set=(i,x,y,v=.95)=>p[i]={x,y,z:0,visibility:v,presence:1};
  set(0,.5,kind==='head_down'?.69:.37);
  set(2,.39,.32);set(5,.61,.32);
  set(11,.28,.62);set(12,.72,.62);
  set(23,.36,.94);set(24,.64,.94);
  if(kind==='lying') {set(11,.24,.28);set(12,.24,.57);set(23,.78,.31);set(24,.78,.61);}
  return {poseLandmarks:[p],poseAgeMs:0};
}
function handCover() {
  const pts=Array.from({length:21},(_,i)=>({x:.30+(i%5)*.04,y:.25+Math.floor(i/5)*.04,z:0}));
  return {handLandmarks:[pts],handAgeMs:0};
}
function raw(mode='awake') {
  const data={width:640,height:480,quality:{mean:130},faceLandmarks:[],poseLandmarks:[],handLandmarks:[]};
  if(mode==='away')return data;
  Object.assign(data,body(mode==='lying'?'lying':mode==='head_down'?'head_down':'upright'));
  if(mode!=='hidden')Object.assign(data,face(mode==='sleep'||mode==='wink',mode==='wink'));
  if(mode==='covered')Object.assign(data,handCover());
  return data;
}
module.exports={face,body,handCover,raw};
