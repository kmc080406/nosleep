# 모델 출처와 구현 범위

2026-09-07 기준 공개된 Google MediaPipe 모델 경로와 공식 Web API를 사용합니다.

## 사용 자산

| 자산 | 선택 버전 | 배포 방식 |
|---|---|---|
| @mediapipe/tasks-vision JavaScript + WASM | 0.10.35 고정 | 사용자의 브라우저에서 jsDelivr 다운로드 |
| Face Landmarker | float16 / checkpoint 1 | Google 공개 저장소에서 다운로드 |
| Pose Landmarker Full | float16 / checkpoint 1 | Google 공개 저장소에서 다운로드 |
| Hand Landmarker | float16 / checkpoint 1 | Google 공개 저장소에서 다운로드 |

정확한 URL은 `models/manifest.json` 및 `assets/config.js`에 있습니다. SDK 파일·가중치 파일·훈련 데이터·사용자 사진은 이 ZIP에 포함하지 않았습니다. 다운로드 시 서버의 최신 경로로 임의 변경하지 않고 위 경로를 사용합니다.

## 사전학습 모델이 하는 일

얼굴·몸·손의 좌표와 표정 관련 계수를 추정합니다. `자는 사람 / 깨어 있는 사람 / 책상에 엎드린 사람`이라는 행동 클래스를 직접 출력하는 모델이 아닙니다. 사용자 식별이나 신원 확인도 하지 않습니다.

## 이 프로젝트에서 추가한 일

실제 이미지 비율을 반영한 눈의 세로·가로 비율, 양쪽 눈 깜박임 계수, 손과 눈의 투영 위치 겹침, 어깨·머리·골반의 상대 위치를 사용합니다. 시작 시 눈을 뜬 모습을 기준으로 짧게 보정합니다. 신호의 종류와 원인이 같은 상태가 연속될 때만 알림 시간을 누적합니다.

손이 눈을 가리는 경우는 가림 확인 신호이지 수면의 증거가 아닙니다. 머리 숙임과 누운 자세도 확인 신호입니다. 얼굴이 안 보인다고 바로 수면으로 처리하지 않습니다.

다양한 졸음/비졸음 영상 데이터셋으로 이 규칙을 학습하거나 검증하지 않았습니다. 전체 자세·각도를 다루는 완성된 수면 분류기라고 해석해서는 안 됩니다. 모든 기준값은 실제 대상 환경에서 조정·검증할 초기값입니다.

## 출처 / 권리

이 프로젝트와 Google 또는 MediaPipe 사이에 공식 제휴나 보증은 없습니다. MediaPipe 소프트웨어 및 모델은 원 제공자의 자산이며, 원 제공자의 문서와 이용 조건을 따릅니다. 이 배포물은 해당 라이브러리 코드나 모델 가중치를 재포장하지 않고 런타임에서 가져오도록 참조합니다.

- 공식 소스: https://github.com/google-ai-edge/mediapipe
- 공식 라이선스 파일: https://github.com/google-ai-edge/mediapipe/blob/master/LICENSE
- Face 모델 개요: https://ai.google.dev/edge/mediapipe/solutions/vision/face_landmarker
- Pose 모델 개요: https://ai.google.dev/edge/mediapipe/solutions/vision/pose_landmarker
- Hand 모델 개요: https://ai.google.dev/edge/mediapipe/solutions/vision/hand_landmarker

`made by 김민찬`은 웹 프로젝트의 제작자 표기이며, 공개 모델의 원 개발자를 뜻하지 않습니다.
