'use strict';

/** Public pretrained landmark models. These are NOT trained sleep classifiers. */
const JOLJIMA_VISION = Object.freeze({
  version: '0.10.35',
  libraryUrl: 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.35/vision_bundle.mjs',
  wasmRoot: 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.35/wasm',
  models: Object.freeze({
    face: 'https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task',
    pose: 'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_full/float16/1/pose_landmarker_full.task',
    hand: 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task',
  }),
  delegate: 'CPU', // Worker CPU: does not require a discrete GPU.
  preferWorker: true,
  bodyIntervalMs: 250,
  handIntervalMs: 250,
  assetTimeoutMs: 45000,
});
const MIRROR_INPUT = true; // Preview only; analysis uses the entire, unmirrored frame.
const JOLJIMA_LIMITS = Object.freeze({
  sampleIntervalMs: 150,
  maxFrameGapMs: 1500,
  predictionTimeoutMs: 8000,
  cameraTimeoutMs: 20000,
  playbackTimeoutMs: 10000,
  modelTimeoutMs: 120000,
  cooldownMs: 2000,
});
