'use strict';

/**
 * This function is also serialized into a classic Worker. Keep it self-contained.
 * MediaPipe runs locally; only model/SDK downloads go over the network.
 */
async function JoljimaVisionRuntime(config, progress = () => {}, externalSignal = null) {
  const tasks = [];
  let face, pose, hand;
  let latestPose = null, latestHand = null;
  let poseAt = -Infinity, handAt = -Infinity, lastAt = -Infinity;
  let closed = false;
  const makeCanvas = () => typeof OffscreenCanvas !== 'undefined'
    ? new OffscreenCanvas(24, 18) : Object.assign(document.createElement('canvas'), { width: 24, height: 18 });
  const qualityCanvas = makeCanvas();
  const qualityContext = qualityCanvas.getContext('2d', { willReadFrequently: true });
  const abort = new AbortController();
  const dispose = () => {
    closed = true;
    abort.abort();
    externalSignal?.removeEventListener('abort', dispose);
    for (const task of tasks) { try { task.close(); } catch (_) {} }
    tasks.length = 0;
  };
  externalSignal?.addEventListener('abort', dispose, { once: true });
  if (externalSignal?.aborted) dispose();
  async function modelBuffer(url) {
    if (closed) throw new Error('AI 연결이 취소됐어요.');
    const controller = new AbortController();
    const cancel = () => controller.abort();
    abort.signal.addEventListener('abort', cancel, { once: true });
    const timer = setTimeout(cancel, config.assetTimeoutMs);
    try {
      const response = await fetch(url, { signal: controller.signal, credentials: 'omit', cache: 'default', referrerPolicy: 'no-referrer' });
      if (!response.ok) throw new Error('모델 파일을 받지 못했어요. HTTP ' + response.status);
      const size = Number(response.headers.get('content-length'));
      if (size > 64 * 1024 * 1024) throw new Error('모델 파일 크기가 예상 범위를 벗어났어요.');
      const buffer = await response.arrayBuffer();
      if (buffer.byteLength < 1024 || buffer.byteLength > 64 * 1024 * 1024) throw new Error('모델 파일 형식을 확인해 주세요.');
      return new Uint8Array(buffer);
    } finally {
      clearTimeout(timer);
      abort.signal.removeEventListener('abort', cancel);
    }
  }
  try {
    progress('AI 실행 도구를 불러오고 있어요.');
    if (closed) throw new Error('AI 연결이 취소됐어요.');
    const library = await import(config.libraryUrl);
    if (closed) throw new Error('AI 연결이 취소됐어요.');
    const wasm = await library.FilesetResolver.forVisionTasks(config.wasmRoot);
    const entries = [
      ['face', library.FaceLandmarker, { numFaces: 2, outputFaceBlendshapes: true,
        minFaceDetectionConfidence: .55, minFacePresenceConfidence: .6, minTrackingConfidence: .55 }, '얼굴 모델을 준비하고 있어요. 1 / 3'],
      ['pose', library.PoseLandmarker, { numPoses: 2, outputSegmentationMasks: false,
        minPoseDetectionConfidence: .55, minPosePresenceConfidence: .6, minTrackingConfidence: .55 }, '몸 자세 모델을 준비하고 있어요. 2 / 3'],
      ['hand', library.HandLandmarker, { numHands: 2,
        minHandDetectionConfidence: .55, minHandPresenceConfidence: .6, minTrackingConfidence: .55 }, '손 모델을 준비하고 있어요. 3 / 3'],
    ];
    for (const [key, Constructor, options, message] of entries) {
      if (closed) throw new Error('모델 연결이 취소됐어요.');
      progress(message);
      const buffer = await modelBuffer(config.models[key]);
      const canvas = typeof OffscreenCanvas !== 'undefined' ? new OffscreenCanvas(1, 1) : document.createElement('canvas');
      const task = await Constructor.createFromOptions(wasm, {
        ...options, canvas, runningMode: 'VIDEO',
        baseOptions: { modelAssetBuffer: buffer, delegate: config.delegate },
      });
      if (closed) { task.close(); throw new Error('AI 연결이 취소됐어요.'); }
      tasks.push(task);
      if (key === 'face') face = task;
      if (key === 'pose') pose = task;
      if (key === 'hand') hand = task;
    }
  } catch (error) { dispose(); throw error; }

  function detect(frame, at) {
    if (closed) throw new Error('AI 분석기가 종료됐어요.');
    if (!Number.isFinite(at) || at <= lastAt) throw new Error('프레임 시간이 올바르지 않아요.');
    lastAt = at;
    const result = face.detectForVideo(frame, at);
    if (at - poseAt >= config.bodyIntervalMs || !latestPose) {
      latestPose = pose.detectForVideo(frame, at);
      poseAt = at;
    }
    if (at - handAt >= config.handIntervalMs || !latestHand) {
      latestHand = hand.detectForVideo(frame, at);
      handAt = at;
    }
    let mean = 128;
    if (qualityContext) {
      qualityContext.drawImage(frame, 0, 0, 24, 18);
      const pixels = qualityContext.getImageData(0, 0, 24, 18).data;
      let sum = 0;
      for (let i = 0; i < pixels.length; i += 4) sum += pixels[i] * .2126 + pixels[i + 1] * .7152 + pixels[i + 2] * .0722;
      mean = sum / (pixels.length / 4);
    }
    return {
      width: frame.width, height: frame.height, quality: { mean },
      faceLandmarks: result.faceLandmarks ?? [], faceBlendshapes: result.faceBlendshapes ?? [],
      poseLandmarks: latestPose?.landmarks ?? [], poseAgeMs: at - poseAt,
      handLandmarks: latestHand?.landmarks ?? [], handAgeMs: at - handAt,
    };
  }
  return { detect, close: dispose };
}

/** Worker transport. One frame at a time; no backlog of stale camera frames. */
class JoljimaDetector {
  constructor(config = JOLJIMA_VISION) {
    const absolute = path => new URL(path, document.baseURI).href;
    this.config = { ...config, libraryUrl: absolute(config.libraryUrl),
      wasmRoot: absolute(config.wasmRoot),
      models: Object.fromEntries(Object.entries(config.models).map(([key, path]) => [key, absolute(path)])) };
    this.abort = new AbortController();
    this.worker = null;
    this.runtime = null;
    this.pending = null;
    this.sequence = 0;
    this.closed = false;
    this.analyzer = new JoljimaSignals.Analyzer();
    this.mode = '';
  }
  async load(progress = () => {}) {
    if (this.closed) throw new Error('AI 연결이 취소됐어요.');
    if (this.config.preferWorker && typeof Worker !== 'undefined' && typeof OffscreenCanvas !== 'undefined' && typeof createImageBitmap === 'function') {
      try {
        await this.loadWorker(progress);
        this.mode = 'worker';
        return this;
      } catch (error) {
        this.worker?.terminate();
        this.worker = null;
        if (this.closed) throw error;
        console.warn('Worker unavailable; using the browser main-thread fallback.', error);
        progress('이 브라우저에 맞는 실행 방식으로 다시 준비해요.');
      }
    }
    const runtime = await JoljimaVisionRuntime(this.config, progress, this.abort.signal);
    if (this.closed) { runtime.close(); throw new Error('AI 연결이 취소됐어요.'); }
    this.runtime = runtime;
    this.mode = 'main';
    return this;
  }
  loadWorker(progress) {
    const source = `const createRuntime = ${JoljimaVisionRuntime.toString()};
let runtime = null, busy = false;
self.onmessage = async ({data}) => {
  if (data.type === 'init') {
    try {
      runtime = await createRuntime(data.config, text => self.postMessage({type:'progress',text}));
      self.postMessage({type:'ready'});
    } catch (error) { self.postMessage({type:'error',message:String(error.message || error)}); }
  } else if (data.type === 'frame') {
    try {
      if (busy || !runtime) throw new Error('AI 분석 준비 상태를 확인해 주세요.');
      busy = true;
      const raw = runtime.detect(data.frame, data.at);
      self.postMessage({type:'result',id:data.id,raw});
    } catch (error) { self.postMessage({type:'error',id:data.id,message:String(error.message || error)}); }
    finally { busy = false; data.frame?.close(); }
  }
};`;
    const url = URL.createObjectURL(new Blob([source], { type: 'text/javascript' }));
    return new Promise((resolve, reject) => {
      let ready = false;
      let settled = false;
      let worker;
      try { worker = new Worker(url); } // classic Worker permits the WASM loader's importScripts.
      catch (error) { URL.revokeObjectURL(url); reject(error); return; }
      this.worker = worker;
      const timer = setTimeout(() => finish(new Error('AI 모델 다운로드가 지연돼요. 연결을 확인해 주세요.')), JOLJIMA_LIMITS.modelTimeoutMs - 2000);
      const finish = error => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        URL.revokeObjectURL(url);
        this.cancelLoad = null;
        if (error) reject(error); else resolve();
      };
      this.cancelLoad = () => finish(new Error('AI 연결이 취소됐어요.'));
      worker.onmessage = ({ data }) => {
        if (data.type === 'progress') { if (!this.closed) progress(data.text); return; }
        if (data.type === 'ready') { ready = true; finish(); return; }
        if (data.type === 'result') {
          if (this.pending?.id === data.id) { const pending = this.pending; this.pending = null; pending.resolve(data.raw); }
          return;
        }
        if (data.type === 'error') {
          const error = new Error(data.message || 'AI 분석 중 문제가 발생했어요.');
          if (!ready) finish(error);
          if (this.pending && (data.id === undefined || this.pending.id === data.id)) {
            const pending = this.pending; this.pending = null; pending.reject(error);
          }
        }
      };
      worker.onerror = event => {
        event.preventDefault();
        const error = new Error(event.message || '이 브라우저에서는 AI Worker를 시작하지 못했어요.');
        if (!ready) finish(error);
        if (this.pending) { const pending = this.pending; this.pending = null; pending.reject(error); }
      };
      worker.postMessage({ type: 'init', config: this.config });
    });
  }
  async predict(canvas, at) {
    if (this.closed) throw new Error('AI 분석기가 종료됐어요.');
    let raw;
    if (this.worker) {
      if (this.pending) throw new Error('이전 프레임을 분석하고 있어요.');
      const frame = await createImageBitmap(canvas);
      if (this.closed) { frame.close(); throw new Error('AI 분석기가 종료됐어요.'); }
      const id = ++this.sequence;
      raw = await new Promise((resolve, reject) => {
        this.pending = { id, resolve, reject };
        try { this.worker.postMessage({ type: 'frame', id, frame, at }, [frame]); }
        catch (error) { this.pending = null; frame.close(); reject(error); }
      });
    } else if (this.runtime) raw = this.runtime.detect(canvas, at);
    else throw new Error('AI 모델이 연결되지 않았어요.');
    return this.analyzer.analyze(raw, at);
  }
  resetSession() { this.analyzer.reset(); }
  close() {
    if (this.closed) return;
    this.closed = true;
    this.abort.abort();
    this.cancelLoad?.();
    this.worker?.terminate();
    this.worker = null;
    this.runtime?.close();
    this.runtime = null;
    if (this.pending) { const pending = this.pending; this.pending = null; pending.reject(new Error('AI 분석이 종료됐어요.')); }
  }
  dispose() { this.close(); }
}
