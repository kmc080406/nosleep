'use strict';

/** DOM이나 카메라 없이도 테스트할 수 있는 분류·시간·비동기 유틸리티. */
const JoljimaCore = (() => {
  const KINDS = new Set(['awake', 'sleep', 'check', 'away', 'unknown']);

  class DrowsinessGate {
    constructor(seconds = 5, maxGapMs = 1000) {
      this.seconds = seconds;
      this.maxGapMs = maxGapMs;
      this.reset();
    }

    reset() {
      this.lastAt = null;
      this.lastKind = 'unknown';
      this.lastReason = '';
      this.sleepMs = 0;
      this.fired = false;
    }

    observe(kind, now, reason = '') {
      if (!Number.isFinite(now) || now < 0) {
        this.reset();
        return {
          kind: 'unknown', sleepMs: 0, trigger: false
        };
      }
      if (!KINDS.has(kind)) kind = 'unknown';
      const gap = this.lastAt === null ? 0 : now - this.lastAt;
      const continuous = this.lastAt !== null && gap >= 0 && gap <= this.maxGapMs;
      const active = kind === 'sleep' || kind === 'check';
      const sameSleep = active && this.lastKind === kind && this.lastReason === reason && continuous;
      this.sleepMs = sameSleep ? this.sleepMs + gap : 0;
      if (!sameSleep) this.fired = false;
      const trigger = active && !this.fired && this.sleepMs >= this.seconds * 1000;
      if (trigger) this.fired = true;
      this.lastAt = now;
      this.lastKind = kind;
      this.lastReason = reason;
      return {
        kind, sleepMs: this.sleepMs, trigger
      };
    }
  }

  /** 배열 복사·정렬 없이 가장 높은 유효 분류 점수를 한 번에 찾습니다. */
  function classifyPredictions(predictions, names, threshold = 0.8) {
    if (!Array.isArray(predictions)) return 'unknown';
    let best = null;
    for (const item of predictions) {
      if (!item || typeof item.className !== 'string') continue;
      const value = item.probability;
      if (!Number.isFinite(value) || value < 0 || value > 1) continue;
      if (!best || value > best.probability) best = item;
    }
    if (!best || best.probability < threshold) return 'unknown';
    if (best.className === names.awake) return 'awake';
    if (best.className === names.sleep) return 'sleep';
    if (names.away && best.className === names.away) return 'away';
    return 'unknown';
  }

  function normalizeSettings(saved) {
    return {
      seconds: Number.isInteger(saved?.seconds) && saved.seconds >= 2 && saved.seconds <= 30
      ? saved.seconds : 5,
      sound: typeof saved?.sound === 'boolean' ? saved.sound : true,
    };
  }

  /** 각 키를 따로 읽어 새 설정이 손상되어도 기존 설정으로 복구합니다. */
  function readSettings(storage, key, legacyKey) {
    for (const candidate of [key, legacyKey]) {
      try {
        const raw = storage?.getItem(candidate);
        if (raw === null || raw === undefined) continue;
        const value = JSON.parse(raw);
        if (value && typeof value === 'object' && !Array.isArray(value)) {
          const settings = normalizeSettings(value);
          if (candidate !== key) {
            try {
              storage.setItem(key, JSON.stringify(settings));
            } catch (_) {
            }
          }
          return settings;
        }
      } catch (_) {
        /* 저장 공간이 차단되어도 기본 기능은 작동합니다. */
      }
    }
    return normalizeSettings(null);
  }

  function withTimeout(promise, milliseconds, message) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error(message)), milliseconds);
      Promise.resolve(promise).then(
      value => {
        clearTimeout(timer);
        resolve(value);
      },
      error => {
        clearTimeout(timer);
        reject(error);
      },
      );
    });
  }

  /**
  * 화면 전환으로 이전 요청이 무효화되어도 실제 추론이 끝나기 전에는
  * 다음 추론을 시작하지 않습니다. 타임아웃은 GPU 작업을 취소하지 않습니다.
  */
  class PredictionSlot {
    constructor() {
      this.pending = null;
      this.startedAt = 0;
    }
    get busy() {
      return this.pending !== null;
    }

    run(operation, now) {
      if (this.pending) return null;
      this.startedAt = now;
      const task = Promise.resolve().then(operation);
      this.pending = task;
      const clear = () => {
        if (this.pending === task) this.pending = null;
      };
      task.then(clear, clear);
      return task;
    }
  }

  /** TM 0.8.x의 로드된 모델과 테스트 대역을 모두 안전하게 정리합니다. */
  function disposeModel(model) {
    if (!model) return;
    // 로드된 TM 모델의 LayersModel과 학습용 truncatedModel은 별개입니다.
    const tensors = new Set([model.model, model.truncatedModel].filter(Boolean));
    if (tensors.size) {
      for (const tensor of tensors) {
        try {
          tensor.dispose?.();
        } catch (_) {
        }
      }
    } else {
      try {
        model.dispose?.();
      } catch (_) {
      }
    }
  }

  return Object.freeze({
    DrowsinessGate, classifyPredictions, normalizeSettings, readSettings,
    withTimeout, PredictionSlot, disposeModel,
  });
})();
