'use strict';

/**
 * Geometric evidence, not a medical / behavioural classifier.
 * All coordinates use real image aspect ratio. Unknown is never treated as asleep.
 * Thresholds are engineering starting points, NOT externally validated accuracy.
 */
const JoljimaSignals = (() => {
  const valid = p => !!p && Number.isFinite(p.x) && Number.isFinite(p.y);
  const inFrame = p => valid(p) && p.x >= .015 && p.x <= .985 && p.y >= .015 && p.y <= .985;
  const visible = (p, t = .55) => inFrame(p) && (p.visibility ?? 0) >= t && (p.presence ?? 1) >= t;
  const point = (p, w, h) => ({ x: p.x * w, y: p.y * h, z: (p.z ?? 0) * w });
  const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
  const mid = (a, b) => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });
  const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
  const median = values => {
    if (!values.length) return null;
    const s = [...values].sort((a, b) => a - b);
    return s[Math.floor(s.length / 2)];
  };
  const signal = (kind, reason, detail = {}) => ({ kind, reason, ...detail });

  function eyeAspect(points, indexes, w, h) {
    if (indexes.some(i => !inFrame(points[i]))) return null;
    const p = indexes.map(i => point(points[i], w, h));
    const width = distance(p[0], p[3]);
    if (width < 7) return null;
    return { width, ear: (distance(p[1], p[5]) + distance(p[2], p[4])) / (2 * width), center: mid(p[0], p[3]) };
  }

  function faceFeatures(raw, w, h) {
    const p = raw.faceLandmarks?.[0];
    if (!p || p.length < 468) return null;
    const left = eyeAspect(p, [33, 160, 158, 133, 153, 144], w, h);
    const right = eyeAspect(p, [362, 385, 387, 263, 373, 380], w, h);
    if (!left || !right || !inFrame(p[1])) return null;
    const span = distance(left.center, right.center);
    if (span < 22) return null;
    const shapes = Object.fromEntries((raw.faceBlendshapes?.[0]?.categories ?? []).map(v => [v.categoryName, v.score]));
    const shapeL = shapes.eyeBlinkLeft;
    const shapeR = shapes.eyeBlinkRight;
    const roll = Math.abs(Math.atan2(right.center.y - left.center.y, Math.abs(right.center.x - left.center.x)) * 180 / Math.PI);
    const zSkew = Math.abs((p[33].z ?? 0) - (p[263].z ?? 0)) * w / span;
    const balance = Math.min(left.width, right.width) / Math.max(left.width, right.width);
    // Oblique/near-profile eyes are explicitly not used for a sleep conclusion.
    const reliable = roll < 60 && zSkew < .95 && balance > .52 &&
      Number.isFinite(shapeL) && Number.isFinite(shapeR);
    return {
      left, right, span, roll, zSkew, balance, reliable,
      nose: point(p[1], w, h), center: mid(left.center, right.center),
      blinkL: shapeL ?? 0, blinkR: shapeR ?? 0,
      ear: (left.ear + right.ear) / 2,
    };
  }

  function bodyFeatures(raw, w, h) {
    if ((raw.poseAgeMs ?? 0) > 450) return null;
    const p = raw.poseLandmarks?.[0];
    if (!p || p.length < 25) return null;
    const shouldersGood = visible(p[11]) && visible(p[12]);
    const anchors = [0, 11, 12, 23, 24].filter(i => visible(p[i]));
    if (anchors.length < 2) return null;
    const shoulders = shouldersGood ? mid(point(p[11], w, h), point(p[12], w, h)) : null;
    const span = shouldersGood ? distance(point(p[11], w, h), point(p[12], w, h)) : 0;
    const nose = visible(p[0], .45) ? point(p[0], w, h) : null;
    const hipsGood = visible(p[23], .65) && visible(p[24], .65);
    const hips = hipsGood ? mid(point(p[23], w, h), point(p[24], w, h)) : null;
    const torso = shoulders && hips ? distance(shoulders, hips) : 0;
    const lying = torso > 55 && shoulders && hips &&
      Math.abs(hips.x - shoulders.x) > Math.abs(hips.y - shoulders.y) * 1.7;
    const headRise = shoulders && nose && span > 45 ? (shoulders.y - nose.y) / span : null;
    const eyeAnchors = visible(p[2], .35) && visible(p[5], .35)
      ? [point(p[2], w, h), point(p[5], w, h)] : null;
    return { p, shoulders, span, nose, hips, lying: !!lying, headRise, eyeAnchors, solid: shouldersGood && span > 45 };
  }

  function pointSegmentDistance(p, a, b) {
    const dx = b.x - a.x, dy = b.y - a.y;
    const d = dx * dx + dy * dy;
    const t = d ? clamp(((p.x - a.x) * dx + (p.y - a.y) * dy) / d, 0, 1) : 0;
    return distance(p, { x: a.x + t * dx, y: a.y + t * dy });
  }
  function hull(points) {
    const pts = [...points].sort((a, b) => a.x - b.x || a.y - b.y);
    const cross = (o, a, b) => (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);
    const lower = [], upper = [];
    for (const p of pts) { while (lower.length >= 2 && cross(lower.at(-2), lower.at(-1), p) <= 0) lower.pop(); lower.push(p); }
    for (let i = pts.length - 1; i >= 0; i--) { const p = pts[i]; while (upper.length >= 2 && cross(upper.at(-2), upper.at(-1), p) <= 0) upper.pop(); upper.push(p); }
    lower.pop(); upper.pop();
    return [...lower, ...upper];
  }
  function insideOrNear(p, polygon, margin) {
    if (polygon.length < 3) return false;
    let inside = false;
    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
      const a = polygon[i], b = polygon[j];
      if (pointSegmentDistance(p, a, b) <= margin) return true;
      if ((a.y > p.y) !== (b.y > p.y) && p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y) + a.x) inside = !inside;
    }
    return inside;
  }

  /** A hand projected over an eye is a visibility check, NEVER proof of sleeping. */
  function eyeOcclusion(raw, face, body, w, h) {
    if ((raw.handAgeMs ?? 0) > 450) return false;
    let eyes = face ? [face.left.center, face.right.center] : body?.eyeAnchors;
    if (!eyes || distance(eyes[0], eyes[1]) < 12) return false;
    const span = distance(eyes[0], eyes[1]);
    for (const hand of raw.handLandmarks ?? []) {
      if (!Array.isArray(hand) || hand.filter(inFrame).length < 12) continue;
      const polygon = hull(hand.filter(inFrame).map(p => point(p, w, h)));
      const bounds = polygon.reduce((r, p) => ({ minX: Math.min(r.minX, p.x), maxX: Math.max(r.maxX, p.x), minY: Math.min(r.minY, p.y), maxY: Math.max(r.maxY, p.y) }), { minX: Infinity, maxX: -Infinity, minY: Infinity, maxY: -Infinity });
      if (Math.max(bounds.maxX - bounds.minX, bounds.maxY - bounds.minY) < span * .35) continue;
      if (eyes.some(p => insideOrNear(p, polygon, span * .12))) return true;
    }
    return false;
  }

  class Analyzer {
    constructor() { this.reset(); }
    reset() {
      this.startedAt = null;
      this.openSamples = [];
      this.riseSamples = [];
      this.openReference = null;
      this.riseReference = null;
      this.calibrationDone = false;
      this.lastAt = null;
    }
    analyze(raw, now) {
      if (!raw || !Number.isFinite(now) || now < 0) return signal('unknown', 'unavailable');
      if (this.lastAt !== null && now <= this.lastAt) return signal('unknown', 'stale');
      this.lastAt = now;
      if (this.startedAt === null) this.startedAt = now;
      const w = raw.width || 640, h = raw.height || 480;
      if ((raw.faceLandmarks?.length ?? 0) > 1 || (raw.poseLandmarks?.length ?? 0) > 1) return signal('unknown', 'multiple');
      if (raw.quality && raw.quality.mean < 18) return signal('unknown', 'dark');
      const face = faceFeatures(raw, w, h);
      const body = bodyFeatures(raw, w, h);
      const covered = eyeOcclusion(raw, face, body, w, h);
      const clearOpen = face?.reliable && face.blinkL < .22 && face.blinkR < .22 && face.ear > .105 && face.ear < .5 && !covered;
      if (!this.calibrationDone) {
        if (clearOpen) {
          this.openSamples.push(face.ear);
          if (body?.headRise > .2 && body.headRise < 1.5) this.riseSamples.push(body.headRise);
        }
        const elapsed = now - this.startedAt;
        if ((this.openSamples.length >= 12 && elapsed >= 1800) || elapsed >= 6000) {
          this.openReference = this.openSamples.length >= 6 ? clamp(median(this.openSamples), .13, .38) : .27;
          this.riseReference = this.riseSamples.length >= 4 ? median(this.riseSamples) : null;
          this.calibrationDone = true;
          this.openSamples.length = this.riseSamples.length = 0;
        } else return signal('unknown', 'calibrating');
      }
      if (covered) return signal('check', 'covered');
      if (face?.reliable) {
        const closedEar = clamp(this.openReference * .60, .075, .205);
        const softEar = clamp(this.openReference * .82, .11, .26);
        const closed = (face.blinkL >= .55 && face.blinkR >= .55 && face.ear < softEar) ||
          (face.left.ear < closedEar && face.right.ear < closedEar && face.blinkL > .28 && face.blinkR > .28);
        if (closed) return signal('sleep', 'eyes_closed');
      }
      if (body?.lying) return signal('check', 'lying');
      if (body?.solid && body.headRise !== null) {
        const drop = this.riseReference !== null ? this.riseReference - body.headRise : 0;
        // Normal reading / a small nod must not be equated with sleeping.
        const extreme = body.headRise < -.04 || (body.headRise < .12 && drop > .30);
        if (extreme) return signal('check', 'head_down');
      }
      if (face?.reliable) {
        const open = face.blinkL < .45 && face.blinkR < .45 && face.ear > this.openReference * .67;
        return open ? signal('awake', 'eyes_open') : signal('unknown', 'unclear_eyes');
      }
      if (face) return signal('check', 'angle');
      if (body?.solid) return signal('check', 'face_hidden');
      return signal('away', 'not_found');
    }
  }
  return Object.freeze({ Analyzer, faceFeatures, bodyFeatures, eyeOcclusion, eyeAspect, median });
})();
