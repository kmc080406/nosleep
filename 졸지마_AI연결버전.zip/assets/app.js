'use strict';

(() => {
  const {
    DrowsinessGate, readSettings, withTimeout,
    PredictionSlot
  } = JoljimaCore;
  // DOM 참조는 최초 한 번만 수집합니다.
  const elements = Object.fromEntries(
  Array.from(document.querySelectorAll('[id]'), element => [element.id, element]),
  );
  const $ = id => elements[id];
  const setText = (id, value) => {
    if ($(id).textContent !== String(value)) $(id).textContent = String(value);
  };
  const show = (id, visible = true) => {
    if ($(id).hidden === visible) $(id).hidden = !visible;
  };
  const storageKey = 'joljima.simple.settings.v1';
  let storage = null;
  try {
    storage = window.localStorage;
  } catch (_) {
  }
  const settings = readSettings(storage, storageKey, 'jajima.simple.settings.v1');
  const app = {
    screen: 'intro', live: true, session: 0, cameraRequest: 0,
    stream: null, model: null, modelPromise: null, cameraVisible: false,
    paused: false, panelOpen: false, frameId: 0, frameSerial: 0,
    processedFrame: -1, lastFrameAt: 0, lastVideoTime: -1,
    loopId: 0, runId: 0, cooldownUntil: 0, alarmTest: false,
    toastId: 0, wakeLock: null, wakeVersion: 0, wakePending: false, audio: null,
    modelVersion: 0, loadingModel: null, alarmReason: 'eyes_closed', lastObservation: null, trackCleanups: [], focusId: 0,
    audioNodes: new Set(), alarmInterval: 0, soundTimeouts: new Set()
  };
  const gate = new DrowsinessGate(settings.seconds, JOLJIMA_LIMITS.maxFrameGapMs);
  const predictions = new PredictionSlot();
  // 미리보기에는 추론용 캔버스와 실행 라이브러리가 필요하지 않습니다.
  let canvas = null;
  let context = null;
  const video = $('cameraVideo');
  const dialog = $('settingsDialog');
  const circleLength = 2 * Math.PI * 134;
  const routes = {
    intro: 'introScreen', monitor: 'monitorScreen', loading: 'loadingScreen', error: 'errorScreen', alarm: 'alarmScreen'
  };
  const headings = {
    intro: 'introTitle', monitor: 'monitorTitle', loading: 'loadingTitle', error: 'errorTitle', alarm: 'alarmTitle'
  };
  const clockIcon = $('liveDetail').querySelector('svg');
  const readoutValue = $('sleepReadout').firstChild;
  const readoutLimit = $('sleepReadout').querySelector('span');
  const messages = Object.freeze({
    preview: ['준비됐어요.', '모델을 연결하면 감지가 시작돼요.'],
    awake: ['눈을 뜨고 있어요.', '하던 일에 집중하세요. 졸면 깨워드릴게요.'],
    sleep: ['눈 감김이 이어지고 있어요.', ''],
    check: ['모습을 확인해 주세요.', ''],
    away: ['사람을 찾고 있어요.', '모습이 보이면 다시 확인할게요.'],
    unknown: ['모습을 확인하고 있어요.', '얼굴과 어깨가 보이게 앉아 주세요.'],
    paused: ['잠시 멈췄어요.', '준비되면 다시 이어서 해요.'],
  });
  let renderKey = '';
  let lastOffset = '';

  // ── 설정 · 화면 갱신 ──────────────────────────────────────────
  function saveSettings() {
    try {
      storage?.setItem(storageKey, JSON.stringify(settings));
    } catch (_) {
    }
  }
  function syncSettings() {
    gate.seconds = settings.seconds;
    $('delayInput').value = String(settings.seconds);
    $('delayInput').setAttribute('aria-valuetext', settings.seconds + '초');
    setText('delayValue', settings.seconds + '초');
    $('soundInput').checked = settings.sound;
    setText('introSubtitle', '졸음이 ' + settings.seconds + '초 이어지면 알려드려요.');
    setText('delayLabel', settings.seconds + '초 후 알림' + (settings.sound ? '' : ' · 무음'));
    setText('introNote', app.live ? '시작하면 카메라로 감지해요.' : '지금은 모델 연결 전 미리보기예요.');
  }
  function toast(message) {
    clearTimeout(app.toastId);
    setText('toast', message);
    show('toast');
    app.toastId = setTimeout(() => show('toast', false), 4500);
  }
  function setScreen(name, focus = true) {
    app.screen = name;
    document.body.dataset.screen = name;
    for (const [key, id] of Object.entries(routes)) show(id, key === name);
    const monitor = name === 'monitor';
    show('credit', !monitor);
    show('modeTag', monitor);
    show('settingsButton', monitor && !app.paused);
    setText('modeTag', app.paused ? '일시 정지' : app.live ? '감지 중' : '미리보기');
    $('modeTag').classList.toggle('live', app.live && !app.paused);
    let footer = '영상은 저장하거나 전송하지 않아요.';
    if (monitor) footer = app.paused ? '잠시 멈춘 동안에는 카메라도 꺼져 있어요.' : app.live ? '감지하려면 이 화면을 열어 두세요.' : '영상은 저장하거나 전송하지 않아요.';
    if (name === 'alarm') footer = settings.sound ? '버튼을 누르면 알림이 멈춰요.' : '소리 없이 화면으로 알리고 있어요.';
    setText('footerText', footer);
    cancelAnimationFrame(app.focusId);
    if (focus) app.focusId = requestAnimationFrame(() => {
      app.focusId = 0;
      if (app.screen === name && !document.hidden) $(headings[name]).focus({
        preventScroll: true
      });
    });
  }
  function renderState(kind, ms = 0, reason = '') {
    if (!Object.hasOwn(messages, kind)) kind = 'unknown';
    const key = `${kind}:${reason}:${settings.seconds}:${app.cameraVisible}`;
    const sleeping = kind === 'sleep' || kind === 'check';
    if (renderKey !== key) {
      renderKey = key;
      $('visual').dataset.kind = kind;
      let [title, base] = messages[kind];
      const details = {
        calibrating: ['정면을 잠깐 봐 주세요.', '눈을 뜬 기준을 맞추고 있어요.'],
        dark: ['화면이 너무 어두워요.', '조명을 켜고 카메라가 가려졌는지 확인해 주세요.'],
        multiple: ['한 사람만 보여 주세요.', '여러 사람이 보이면 판단을 멈춰요.'],
        unclear_eyes: ['눈을 확인하고 있어요.', '정면에서 눈이 잘 보이게 해 주세요.'],
        covered: ['눈이 잘 안 보여요.', ''],
        lying: ['누운 자세로 보여요.', ''],
        head_down: ['고개가 많이 내려갔어요.', ''],
        face_hidden: ['얼굴을 확인할 수 없어요.', ''],
        angle: ['정면에서 확인해 주세요.', ''],
      };
      if (details[reason]) [title, base] = details[reason];
      const sub = sleeping
      ? settings.seconds + (kind === 'sleep' ? '초가 되면 깨워드릴게요.' : '초 이어지면 확인 알림을 드려요.')
      : kind === 'preview' && app.cameraVisible ? '카메라 화면만 확인하고 있어요.' : base;
      setText('monitorTitle', title);
      setText('monitorSubtitle', sub);
      show('delayLabel', !sleeping && kind !== 'paused');
      clockIcon.style.display = sleeping || kind === 'paused' ? 'none' : '';
      show('sleepReadout', sleeping);
      readoutLimit.textContent = '/ ' + settings.seconds + '초';
    }
    const elapsed = sleeping ? Math.min(Math.max(ms, 0), settings.seconds * 1000) : 0;
    if (sleeping) {
      const value = (elapsed / 1000).toFixed(1) + '초';
      if (readoutValue.nodeValue !== value) readoutValue.nodeValue = value;
    }
    const offset = (circleLength * (1 - elapsed / (settings.seconds * 1000))).toFixed(3);
    if (lastOffset !== offset) {
      $('ringFill').style.strokeDashoffset = offset;
      lastOffset = offset;
    }
  }
  function cameraUI(visible) {
    app.cameraVisible = visible;
    $('visual').dataset.preview = String(visible);
    video.setAttribute('aria-hidden', String(!visible));
    $('cameraButton').setAttribute('aria-pressed', String(visible));
    $('cameraButton').setAttribute('aria-label', visible ? (app.live ? '카메라 미리보기 숨기기. 감지는 계속돼요.' : '카메라 미리보기 끄기') : '카메라 미리보기 켜기');
    $('cameraButton').title = visible && app.live ? '화면만 숨기고 감지는 계속해요.' : '';
    setText('cameraButtonLabel', visible ? '화면 숨기기' : '카메라 보기');
    setText('cameraLabel', app.live ? '내 카메라' : '미리보기 · 분석 안 함');
    if (!app.live && app.screen === 'monitor' && !app.paused) renderState('preview');
  }
  // ── 카메라 수명과 새 프레임 추적 ──────────────────────────────
  function stopFrameWatch() {
    if (app.frameId && video.cancelVideoFrameCallback) {
      try {
        video.cancelVideoFrameCallback(app.frameId);
      } catch (_) {
      }
    }
    app.frameId = 0;
  }
  function watchFrames() {
    stopFrameWatch();
    app.frameSerial = 0;
    app.processedFrame = -1;
    app.lastVideoTime = -1;
    app.lastFrameAt = performance.now();
    if (!app.live || !video.requestVideoFrameCallback) return;
    const stream = app.stream;
    const request = app.cameraRequest;
    const onFrame = (now) => {
      if (app.stream !== stream || request !== app.cameraRequest || !stream) return;
      app.frameSerial++;
      app.lastFrameAt = now;
      app.frameId = video.requestVideoFrameCallback(onFrame);
    };
    app.frameId = video.requestVideoFrameCallback(onFrame);
  }
  function stopCamera() {
    app.cameraRequest++;
    stopFrameWatch();
    for (const cleanup of app.trackCleanups) cleanup();
    app.trackCleanups.length = 0;
    const stream = app.stream;
    app.stream = null;
    if (stream) stream.getTracks().forEach(track => track.stop());
    video.pause();
    video.srcObject = null;
    cameraUI(false);
    $('cameraButton').disabled = false;
  }
  function cameraError(error) {
    const descriptions = {
      NotAllowedError: '카메라 권한을 허용한 뒤 다시 시작해 주세요.',
      NotFoundError: '연결된 카메라를 찾지 못했어요.',
      NotReadableError: '다른 앱에서 카메라를 사용 중인지 확인해 주세요.',
      SecurityError: '카메라를 사용하려면 HTTPS 또는 localhost에서 열어 주세요.'
    };
    return descriptions[error && error.name] || (error && error.message) || '카메라를 연결하지 못했어요.';
  }
  async function ensureCamera(session) {
    if (app.stream && app.stream.getVideoTracks().some(track => track.readyState === 'live')) return;
    if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) {
      throw new Error('카메라를 사용하려면 HTTPS 또는 localhost에서 열어 주세요.');
    }
    const requestId = ++app.cameraRequest;
    const cancelled = () => session !== app.session || requestId !== app.cameraRequest || document.hidden;
    let expired = false;
    let acquired = null;
    const request = navigator.mediaDevices.getUserMedia({
      audio: false,
      video: {
        facingMode: 'user', width: {
          ideal: 640
        }, height: {
          ideal: 480
        },
        frameRate: {
          ideal: 20, max: 30
        },
      },
    }).then(stream => {
      // 권한 요청은 취소할 수 없으므로 늦게 도착한 스트림도 바로 닫습니다.
      if (expired || cancelled()) {
        stream.getTracks().forEach(track => track.stop());
        throw new Error('카메라 요청이 취소됐어요.');
      }
      acquired = stream;
      return stream;
    });
    try {
      const stream = await withTimeout(request, JOLJIMA_LIMITS.cameraTimeoutMs,
      '카메라 권한 응답을 기다리다 멈췄어요. 권한을 확인해 주세요.');
      if (cancelled()) throw new Error('카메라 요청이 취소됐어요.');
      app.stream = stream;
      video.srcObject = stream;
      video.muted = true;
      await withTimeout(video.play(), JOLJIMA_LIMITS.playbackTimeoutMs,
      '카메라 화면을 재생하지 못했어요. 다시 시도해 주세요.');
      if (cancelled()) throw new Error('카메라 요청이 취소됐어요.');
      watchFrames();
      for (const track of stream.getVideoTracks()) {
        const ended = () => {
          if (app.stream !== stream) return;
          if (app.live && ['monitor', 'alarm'].includes(app.screen)) {
            pauseSession();
            toast('카메라 연결이 끊겼어요. 연결 후 이어서 해 주세요.');
          } else {
            stopCamera();
            gate.reset();
            toast('카메라 연결이 끊겼어요.');
          }
        };
        track.addEventListener('ended', ended, {
          once: true
        });
        app.trackCleanups.push(() => track.removeEventListener('ended', ended));
      }
    } catch (error) {
      expired = true;
      if (requestId === app.cameraRequest) stopCamera();
      if (acquired) acquired.getTracks().forEach(track => track.stop());
      throw error;
    }
  }
  async function toggleCamera() {
    if (app.screen !== 'monitor' || app.paused || app.panelOpen || $('cameraButton').disabled) return;
    if (app.cameraVisible) {
      cameraUI(false);
      // In real detection, hiding the preview never stops inference.
      if (!app.live) stopCamera();
      return;
    }
    const session = app.session;
    $('cameraButton').disabled = true;
    setText('cameraButtonLabel', '연결 중…');
    try {
      await ensureCamera(session);
      if (session === app.session && app.screen === 'monitor' && !app.paused && !document.hidden && app.stream) cameraUI(true);
    } catch (error) {
      if (session === app.session && app.screen === 'monitor' && !app.paused) {
        stopCamera();
        toast(cameraError(error));
      }
    } finally {
      if (session === app.session) {
        $('cameraButton').disabled = false;
        setText('cameraButtonLabel', app.cameraVisible ? '화면 숨기기' : '카메라 보기');
      }
    }
  }

  // ── 공개 모델 지연 로드 · 단일 추론 루프 ───────────────────
  async function loadModel() {
    if (app.model && !app.model.closed) return app.model;
    if (app.modelPromise) return app.modelPromise;
    const version = app.modelVersion;
    const detector = new JoljimaDetector();
    app.loadingModel = detector;
    const task = (async () => {
      try {
        await withTimeout(detector.load(message => {
          if (version === app.modelVersion && app.screen === 'loading') setText('loadingSubtitle', message);
        }), JOLJIMA_LIMITS.modelTimeoutMs, '공개 모델을 불러오지 못했어요. 인터넷 연결을 확인해 주세요.');
        if (version !== app.modelVersion || detector.closed) throw new Error('AI 연결이 취소됐어요.');
        if (!canvas) {
          canvas = document.createElement('canvas');
          context = canvas.getContext('2d', { alpha: false });
        }
        if (!context) throw new Error('영상 분석을 시작할 수 없는 브라우저예요.');
        app.model = detector;
        app.loadingModel = null;
        return detector;
      } catch (error) {
        detector.close();
        if (app.loadingModel === detector) app.loadingModel = null;
        throw error;
      }
    })();
    app.modelPromise = task;
    task.then(() => {
      if (app.modelPromise === task) app.modelPromise = null;
    }, () => {
      if (app.modelPromise === task) app.modelPromise = null;
    });
    return task;
  }
  function releaseModel() {
    app.modelVersion++;
    app.loadingModel?.close();
    app.model?.close();
    app.loadingModel = null;
    app.model = null;
    app.modelPromise = null;
  }
  function haltLoop() {
    app.runId++;
    clearTimeout(app.loopId);
    app.loopId = 0;
    gate.reset();
  }
  function startLoop() {
    haltLoop();
    if (!app.live || app.paused || app.panelOpen || app.screen !== 'monitor') return;
    const run = app.runId;
    const session = app.session;
    const current = () => run === app.runId && session === app.session &&
    app.screen === 'monitor' && !app.paused && !app.panelOpen && !document.hidden;
    const schedule = (delay = JOLJIMA_LIMITS.sampleIntervalMs) => {
      if (current()) app.loopId = setTimeout(tick, delay);
    };
    async function tick() {
      app.loopId = 0;
      if (!current()) return;
      const now = performance.now();
      // 이전 화면의 추론이 아직 끝나지 않았다면 겹쳐서 실행하지 않습니다.
      if (predictions.busy) {
        gate.reset();
        if (now - predictions.startedAt >= JOLJIMA_LIMITS.predictionTimeoutMs) {
          releaseModel();
          pauseSession();
          toast('AI 응답이 지연되고 있어요. 계속되면 새로고침해 주세요.');
        } else schedule();
        return;
      }
      if (!video.requestVideoFrameCallback && video.currentTime !== app.lastVideoTime) {
        app.lastVideoTime = video.currentTime;
        app.frameSerial++;
        app.lastFrameAt = now;
      }
      const serial = app.frameSerial;
      if (!app.stream || video.readyState < 2 || !video.videoWidth ||
      serial === app.processedFrame || now - app.lastFrameAt > JOLJIMA_LIMITS.maxFrameGapMs) {
        if (now - app.lastFrameAt > JOLJIMA_LIMITS.maxFrameGapMs) {
          gate.reset();
          renderState('unknown');
        }
        schedule();
        return;
      }
      app.processedFrame = serial;
      const capturedAt = now;
      try {
        // Preserve the WHOLE image: a square crop would remove shoulders/hands.
        const scale = Math.min(1, 640 / video.videoWidth, 640 / video.videoHeight);
        const width = Math.round(video.videoWidth * scale);
        const height = Math.round(video.videoHeight * scale);
        if (canvas.width !== width) canvas.width = width;
        if (canvas.height !== height) canvas.height = height;
        context.setTransform(1, 0, 0, 1, 0, 0);
        context.drawImage(video, 0, 0, width, height);
        const task = predictions.run(() => app.model.predict(canvas, capturedAt), now);
        const values = await withTimeout(task, JOLJIMA_LIMITS.predictionTimeoutMs, 'AI 응답 시간이 초과됐어요.');
        if (!current()) return;
        const ended = performance.now();
        if (ended - capturedAt > JOLJIMA_LIMITS.maxFrameGapMs ||
        ended - app.lastFrameAt > JOLJIMA_LIMITS.maxFrameGapMs || ended < app.cooldownUntil) {
          gate.reset();
          renderState('unknown');
        } else {
          // 추론 완료 시각 대신 실제 입력을 읽은 시각으로 연속 시간을 계산합니다.
          app.lastObservation = values;
          const result = gate.observe(values.kind, capturedAt, values.reason);
          renderState(result.kind, result.sleepMs, values.reason);
          if (result.trigger) {
            beginAlarm(false, values.reason);
            return;
          }
        }
      } catch (error) {
        if (current()) {
          releaseModel();
          pauseSession();
          toast('AI 판단이 멈췄어요. 이어서 하기를 눌러 다시 시도해 주세요.');
        }
        return;
      }
      schedule(Math.max(0, JOLJIMA_LIMITS.sampleIntervalMs - (performance.now() - now)));
    }
    tick();
  }
  // ── 화면 잠금 방지 · 알림 소리 ────────────────────────────────
  async function requestWakeLock() {
    if (!app.live || !navigator.wakeLock || document.hidden || app.wakeLock || app.wakePending) return;
    const version = ++app.wakeVersion;
    app.wakePending = true;
    try {
      const lock = await navigator.wakeLock.request('screen');
      if (version !== app.wakeVersion || document.hidden ||
      !['monitor', 'alarm'].includes(app.screen) || app.paused) {
        await lock.release();
        return;
      }
      app.wakeLock = lock;
      lock.addEventListener('release', () => {
        if (app.wakeLock === lock) app.wakeLock = null;
      }, {
        once: true
      });
    } catch (_) {
      /* 선택 기능이므로 지원하지 않아도 감지는 계속합니다. */
    }
    finally {
      if (version === app.wakeVersion) app.wakePending = false;
    }
  }
  function releaseWakeLock() {
    app.wakeVersion++;
    app.wakePending = false;
    const lock = app.wakeLock;
    app.wakeLock = null;
    if (lock) lock.release().catch(() => {
    });
  }
  function primeAudio() {
    if (!settings.sound) return;
    try {
      if (!app.audio) {
        const Audio = window.AudioContext || window.webkitAudioContext;
        if (Audio) app.audio = new Audio();
      }
      if (app.audio && app.audio.state === 'suspended') app.audio.resume().catch(() => {
      });
    } catch (_) {
    }
  }
  function stopAudio() {
    clearInterval(app.alarmInterval);
    app.alarmInterval = 0;
    for (const timer of app.soundTimeouts) clearTimeout(timer);
    app.soundTimeouts.clear();
    try {
      if ('speechSynthesis' in window) speechSynthesis.cancel();
    } catch (_) {
    }
    for (const tone of app.audioNodes) {
      try {
        tone.oscillator.stop();
      } catch (_) {
      }
      tone.oscillator.disconnect();
      tone.gain.disconnect();
    }
    app.audioNodes.clear();
  }
  function alarmSound() {
    if (!settings.sound || app.screen !== 'alarm' || document.hidden) return;
    primeAudio();
    try {
      const audio = app.audio;
      if (audio && audio.state === 'running') {
        [0, .23, .46].forEach((offset, index) => {
          const oscillator = audio.createOscillator(), gain = audio.createGain(), at = audio.currentTime + offset;
          oscillator.type = 'sine';
          oscillator.frequency.value = index === 1 ? 1046.5 : 880;
          gain.gain.setValueAtTime(0, at);
          gain.gain.linearRampToValueAtTime(.22, at + .014);
          gain.gain.exponentialRampToValueAtTime(.001, at + .17);
          oscillator.connect(gain);
          gain.connect(audio.destination);
          const tone = {
            oscillator, gain
          };
          app.audioNodes.add(tone);
          oscillator.onended = () => {
            app.audioNodes.delete(tone);
            oscillator.disconnect();
            gain.disconnect();
          };
          oscillator.start(at);
          oscillator.stop(at + .2);
        });
      }
      if ('speechSynthesis' in window && 'SpeechSynthesisUtterance' in window) {
        const timer = setTimeout(() => {
          app.soundTimeouts.delete(timer);
          if (app.screen !== 'alarm' || !settings.sound || document.hidden) return;
          speechSynthesis.cancel();
          const phrase = new SpeechSynthesisUtterance(app.alarmReason === 'eyes_closed' ? '일어나!' : '모습을 확인해 주세요!');
          phrase.lang = 'ko-KR';
          phrase.rate = 1.03;
          phrase.volume = .85;
          const korean = speechSynthesis.getVoices().find(voice => /^ko[-_]/i.test(voice.lang));
          if (korean) phrase.voice = korean;
          speechSynthesis.speak(phrase);
        }, 800);
        app.soundTimeouts.add(timer);
      }
    } catch (_) {
      /* Visual alert remains available if audio is blocked. */
    }
  }
  function suspendAudio() {
    if (app.audio?.state === 'running') app.audio.suspend().catch(() => {
    });
  }

  // ── 세션 전환 · 이벤트 ────────────────────────────────────────
  function beginAlarm(test, reason = 'eyes_closed') {
    if (app.screen !== 'monitor' || app.paused || document.hidden) return;
    haltLoop();
    stopAudio();
    app.alarmTest = test;
    app.alarmReason = test ? 'eyes_closed' : reason;
    if (dialog.open) {
      app.panelOpen = false;
      dialog.close();
    }
    const isSleep = test || reason === 'eyes_closed';
    const reasons = { covered: '눈 가림', lying: '누운 자세', head_down: '고개 숙임', face_hidden: '얼굴 확인 어려움', angle: '얼굴 각도 확인 어려움' };
    setText('alarmTitle', isSleep ? '일어나!' : '괜찮아요?');
    $('alarmScreen').classList.toggle('check-alarm', !isSleep);
    setText('awakeButtonLabel', isSleep ? '깼어요' : '확인했어요');
    setText('alarmSubtitle', test ? '이렇게 알려드릴게요.' :
      (isSleep ? '눈 감김이 ' : (reasons[reason] || '확인이 어려운 모습') + ' 상태가 ') + settings.seconds + '초 동안 이어졌어요.');
    show('alarmTag', test);
    setScreen('alarm');
    alarmSound();
    app.alarmInterval = setInterval(alarmSound, 4000);
  }
  function dismissAlarm() {
    if (app.screen !== 'alarm' || document.hidden) return;
    stopAudio();
    gate.reset();
    app.cooldownUntil = app.alarmTest ? 0 : performance.now() + JOLJIMA_LIMITS.cooldownMs;
    app.alarmTest = false;
    setScreen('monitor');
    renderState(app.live ? 'unknown' : 'preview');
    if (app.live) {
      const session = app.session;
      withTimeout(video.play(), JOLJIMA_LIMITS.playbackTimeoutMs, '카메라 재생을 다시 확인해 주세요.')
      .then(() => {
        if (session === app.session && app.screen === 'monitor') startLoop();
      })
      .catch(() => {
        if (session === app.session) pauseSession();
      });
    } else startLoop();
  }
  function stopSession() {
    app.session++;
    app.paused = false;
    app.panelOpen = false;
    haltLoop();
    stopAudio();
    suspendAudio();
    stopCamera();
    releaseWakeLock();
    if (dialog.open) dialog.close();
    show('pauseActions', false);
    show('toolbar');
    show('toast', false);
    clearTimeout(app.toastId);
    show('settingsButton', false);
    app.alarmTest = false;
    app.cooldownUntil = 0;
    releaseModel();
    setScreen('intro');
    syncSettings();
  }
  async function startSession() {
    if (document.hidden || (!['intro', 'error'].includes(app.screen) && !app.paused)) return;
    stopCamera();
    primeAudio();
    stopAudio();
    haltLoop();
    const session = ++app.session;
    app.paused = false;
    app.panelOpen = false;
    app.cooldownUntil = 0;
    show('pauseActions', false);
    show('toolbar');
    cameraUI(false);
    show('toast', false);
    if (!app.live) {
      setScreen('monitor');
      renderState('preview');
      return;
    }
    setScreen('loading');
    setText('loadingSubtitle', app.model ? '카메라를 준비하고 있어요.' : 'AI를 불러오고 있어요.');
    try {
      await loadModel();
      if (session !== app.session || document.hidden) return;
      setText('loadingSubtitle', '카메라 권한을 허용해 주세요.');
      await ensureCamera(session);
      if (session !== app.session || document.hidden || !app.stream) return;
      app.model.resetSession();
      setScreen('monitor');
      renderState('unknown', 0, 'calibrating');
      requestWakeLock();
      startLoop();
    } catch (error) {
      if (session !== app.session) return;
      haltLoop();
      stopCamera();
      releaseWakeLock();
      setText('errorMessage', cameraError(error));
      setScreen('error');
    }
  }
  function pauseSession() {
    if (!['monitor', 'loading', 'alarm'].includes(app.screen)) return;
    if (app.screen === 'loading') releaseModel();
    app.session++;
    app.paused = true;
    app.panelOpen = false;
    haltLoop();
    stopAudio();
    suspendAudio();
    stopCamera();
    releaseWakeLock();
    if (dialog.open) dialog.close();
    show('toolbar', false);
    show('pauseActions');
    setScreen('monitor', !document.hidden);
    renderState('paused');
  }
  function openSettings() {
    if (app.screen !== 'monitor' || app.paused || dialog.open) return;
    app.panelOpen = true;
    haltLoop();
    syncSettings();
    renderState(app.live ? 'unknown' : 'preview');
    dialog.showModal();
  }
  function closeSettings() {
    if (dialog.open) dialog.close();
  }
  dialog.addEventListener('close', () => {
    app.panelOpen = false;
    saveSettings();
    if (app.screen === 'monitor' && !app.paused && !document.hidden) {
      gate.reset();
      renderState(app.live ? 'unknown' : 'preview');
      startLoop();
    }
  });
  $('settingsButton').addEventListener('click', openSettings);
  $('settingsDone').addEventListener('click', closeSettings);
  $('delayInput').addEventListener('input', event => {
    const value = Number(event.target.value);
    if (!Number.isInteger(value) || value < 2 || value > 30) return;
    settings.seconds = value;
    gate.reset();
    syncSettings();
  });
  $('delayInput').addEventListener('change', saveSettings);
  $('soundInput').addEventListener('change', event => {
    settings.sound = event.target.checked;
    syncSettings();
    saveSettings();
  });
  $('testAlarmButton').addEventListener('click', () => {
    primeAudio();
    beginAlarm(true);
  });
  $('startButton').addEventListener('click', () => startSession());
  $('retryButton').addEventListener('click', () => startSession());
  $('resumeButton').addEventListener('click', () => startSession());
  $('cameraButton').addEventListener('click', toggleCamera);
  $('awakeButton').addEventListener('click', dismissAlarm);
  ['endButton', 'alarmEndButton', 'pausedEndButton', 'cancelButton', 'errorHomeButton'].forEach(id => $(id).addEventListener('click',
  stopSession));
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      pauseSession();
      stopAudio();
    }
  });
  window.addEventListener('pagehide', () => {
    app.session++;
    haltLoop();
    stopAudio();
    stopCamera();
    releaseWakeLock();
    releaseModel();
    clearTimeout(app.toastId);
    cancelAnimationFrame(app.focusId);
    if (app.audio && app.audio.state !== 'closed') app.audio.close().catch(() => {
    });
    app.audio = null;
  });
  window.addEventListener('pageshow', event => {
    if (event.persisted) stopSession();
  });
  // Mirror only the preview. Analysis receives the full, unmirrored frame.
  video.style.transform = MIRROR_INPUT ? 'scaleX(-1)' : 'none';
  syncSettings();
  setScreen('intro', false);
  cameraUI(false);
})();
